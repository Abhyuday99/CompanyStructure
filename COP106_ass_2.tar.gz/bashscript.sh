#!/bin/bash

javac EmployeeNotFoundException.java
javac Employee.java
javac DNode.java
javac DLinkedList.java
javac Leaf.java
javac Queue.java
javac Tree.java
javac TreeNode.java
javac BST.java
javac CompanyStructure.java
